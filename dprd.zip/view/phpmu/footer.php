<section >
<div class="col-md-12">
	<p class="pull-right">Copyright &copy; <?php echo date('Y'); ?> - DPRD Kab. Keerom, All Rights Reserved<br>&nbsp;</p>
</div>
</section>
